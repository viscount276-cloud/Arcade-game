const canvas = document.getElementById('c'), ctx = canvas.getContext('2d');
let size = 16, w = canvas.width/size, h = canvas.height/size;
let snake, dir, food, running=false, score=0;
function start(){
  snake=[{x:2,y:2}]; dir={x:1,y:0}; placeFood(); score=0; running=true; loop();
}
function placeFood(){ food = {x:Math.floor(Math.random()*w), y:Math.floor(Math.random()*h)}; }
function loop(){
  if(!running) return;
  const head = {x:snake[0].x+dir.x, y:snake[0].y+dir.y};
  if(head.x<0||head.x>=w||head.y<0||head.y>=h || snake.some(s=>s.x===head.x&&s.y===head.y)){ running=false; return; }
  snake.unshift(head);
  if(head.x===food.x&&head.y===food.y){ score++; placeFood(); }
  else snake.pop();
  draw();
  setTimeout(loop,150);
}
function draw(){ ctx.fillStyle='#071a2b'; ctx.fillRect(0,0,canvas.width,canvas.height); ctx.fillStyle='#7df'; snake.forEach(s=>ctx.fillRect(s.x*size+2,s.y*size+2,size-4,size-4)); ctx.fillStyle='#ffb'; ctx.fillRect(food.x*size+2,food.y*size+2,size-4,size-4); document.getElementById('score').textContent = score; }
document.addEventListener('keydown', e=>{ if(e.key==='ArrowUp') dir={x:0,y:-1}; if(e.key==='ArrowDown') dir={x:0,y:1}; if(e.key==='ArrowLeft') dir={x:-1,y:0}; if(e.key==='ArrowRight') dir={x:1,y:0}; });
document.getElementById('start').addEventListener('click', start);
