const symbols = ['🍒','🍋','🔔','⭐','7️⃣','🍀'];
const reels = document.getElementById('reels');
const res = document.getElementById('res');
const spinBtn = document.getElementById('spin');
const autoBtn = document.getElementById('auto');
const betInput = document.getElementById('bet');

function spinOnce(){
  const bet = Math.max(1, Number(betInput.value)||1);
  let out=[];
  for(let i=0;i<3;i++){ out.push(symbols[Math.floor(Math.random()*symbols.length)]); }
  reels.textContent = out.join(' ');
  if(out[0]===out[1] && out[1]===out[2]){ res.textContent = 'Jackpot! +'+(bet*5); adjustCoins(bet*5 - bet); }
  else if(out[0]===out[1] || out[1]===out[2] || out[0]===out[2]){ res.textContent = 'Nice! +'+(bet*2); adjustCoins(bet*2 - bet); }
  else { res.textContent = 'Lose -'+bet; adjustCoins(-bet); }
}
spinBtn.addEventListener('click', spinOnce);
autoBtn.addEventListener('click', async ()=>{ for(let i=0;i<10;i++){ spinOnce(); await new Promise(r=>setTimeout(r,300)); } });

// adjust global coins stored in top-level localStorage
function adjustCoins(delta){
  try{
    const v = Number(localStorage.getItem('pl_coins')||1000);
    localStorage.setItem('pl_coins', v + delta);
  }catch(e){}
}
