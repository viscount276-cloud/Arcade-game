function deck(){ const suits=['♠','♥','♦','♣'], vals=[2,3,4,5,6,7,8,9,10,'J','Q','K','A']; let d=[]; suits.forEach(s=>vals.forEach(v=>d.push(v+''+s))); return d.sort(()=>Math.random()-0.5); }
let d=[], player=[], dealer=[];
function scoreHand(h){ let sum=0, aces=0; h.forEach(c=>{ let v=c.slice(0,-1); if(v==='J'||v==='Q'||v==='K') sum+=10; else if(v==='A'){ sum+=11; aces++; } else sum+=Number(v); }); while(sum>21 && aces){ sum-=10; aces--; } return sum; }
function render(){ document.getElementById('table').innerHTML = '<div>Player: '+player.join(' ')+' ('+scoreHand(player)+')</div><div>Dealer: '+dealer.join(' ')+' ('+scoreHand(dealer)+')</div>'; }
document.getElementById('deal').addEventListener('click', ()=>{ d=deck(); player=[d.pop(),d.pop()]; dealer=[d.pop(),d.pop()]; render(); });
document.getElementById('hit').addEventListener('click', ()=>{ player.push(d.pop()); render(); if(scoreHand(player)>21) document.getElementById('status').textContent='Bust!'; });
document.getElementById('stand').addEventListener('click', ()=>{ while(scoreHand(dealer)<17) dealer.push(d.pop()); render(); const ps=scoreHand(player), ds=scoreHand(dealer); document.getElementById('status').textContent = ps>21? 'You lose' : (ds>21||ps>ds? 'You win' : (ps===ds? 'Push' : 'You lose')); });
