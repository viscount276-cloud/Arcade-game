const { get, set } = idbKeyval;
const canvas = document.getElementById('grid');
const ctx = canvas.getContext('2d');
const cols = 16, rows = 8;
const cellW = canvas.width/cols, cellH = canvas.height/rows;
let grid = Array(rows).fill(0).map(()=>Array(cols).fill(0));
const tileType = document.getElementById('tileType');
const nameInput = document.getElementById('nameInput');

function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  for(let r=0;r<rows;r++){
    for(let c=0;c<cols;c++){
      const v = grid[r][c];
      if(v===1){ ctx.fillStyle='#c77'; ctx.fillRect(c*cellW+2,r*cellH+2,cellW-4,cellH-4); }
      else if(v===2){ ctx.fillStyle='#f6d'; ctx.beginPath(); ctx.arc(c*cellW+cellW/2,r*cellH+cellH/2,8,0,Math.PI*2); ctx.fill(); }
      else if(v===3){ ctx.fillStyle='#6f6'; ctx.fillRect(c*cellW+6,r*cellH+6,cellW-12,cellH-12); }
      ctx.strokeStyle='rgba(255,255,255,0.06)'; ctx.strokeRect(c*cellW,r*cellH,cellW,cellH);
    }
  }
}
canvas.addEventListener('click',(e)=>{
  const rect=canvas.getBoundingClientRect();
  const x=e.clientX-rect.left, y=e.clientY-rect.top;
  const c=Math.floor(x/cellW), r=Math.floor(y/cellH);
  grid[r][c]=Number(tileType.value); draw();
});
document.getElementById('saveBtn').addEventListener('click', async ()=>{
  const name = nameInput.value || ('level_'+Date.now());
  await set('creation:'+name, { name, type:'tilemap', grid, created:Date.now() });
  alert('Saved: '+name);
});
document.getElementById('exportBtn').addEventListener('click', ()=>{
  const name = nameInput.value || ('level_'+Date.now());
  const payload = { name, type:'tilemap', grid };
  const blob = new Blob([JSON.stringify(payload)],{type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download = name+'.json'; a.click();
  URL.revokeObjectURL(url);
});
document.getElementById('loadBtn').addEventListener('click', async ()=>{
  // load last saved creation (naive: load any creation key)
  const keys = await idbKeyval.keys();
  const found = keys.find(k=>k.startsWith('creation:'));
  if(!found){ alert('No saved creations'); return; }
  const d = await idbKeyval.get(found);
  grid = d.grid; nameInput.value = d.name; draw();
});
draw();
