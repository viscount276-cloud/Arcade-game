/*
SimpleP2P - lightweight WebRTC DataChannel helper for manual signaling.
Usage:
  const p = new SimpleP2P();
  const offer = await p.createOffer(); // share with peer A->B
  const answer = await p.createAnswer(offer); // create answer on B
  await p.setRemote(answer); // set on A to finalize
  p.onMessage = (data)=>{...}; p.send({type:'game',payload:...});
Notes: offer/answer are base64-encoded strings (JSON SDP).
This avoids a signaling server (good for offline use/LAN) — just copy/paste or QR.
*/
class SimpleP2P {
  constructor(){ this.pc = null; this.dc = null; this.onMessage = ()=>{}; this.onOpen = ()=>{}; this.onClose=()=>{}; this._init(); }
  _init(){
    const config = { iceServers: [{ urls: ['stun:stun.l.google.com:19302'] }] };
    this.pc = new RTCPeerConnection(config);
    this.pc.ondatachannel = (e)=>{ this._setupDC(e.channel); };
    this.pc.onicecandidate = (e)=>{ /* candidates included in sdp; no trickle */ };
  }
  _setupDC(dc){
    this.dc = dc;
    this.dc.onmessage = (e)=>{ try{ const d=JSON.parse(e.data); this.onMessage(d); }catch(err){} };
    this.dc.onopen = ()=>{ this.onOpen(); };
    this.dc.onclose = ()=>{ this.onClose(); };
  }
  createOffer(){ return new Promise(async (res,rej)=>{
    try{
      const dc = this.pc.createDataChannel('arcade'); this._setupDC(dc);
      const s = await this.pc.createOffer(); await this.pc.setLocalDescription(s);
      // wait for ICE gathering to complete (simple: poll)
      await this._waitForIceComplete();
      const out = btoa(JSON.stringify(this.pc.localDescription));
      res(out);
    }catch(e){ rej(e); }
  }); }
  createAnswer(offerB64){ return new Promise(async (res,rej)=>{
    try{
      const offer = JSON.parse(atob(offerB64));
      await this.pc.setRemoteDescription(offer);
      const ans = await this.pc.createAnswer(); await this.pc.setLocalDescription(ans);
      await this._waitForIceComplete();
      const out = btoa(JSON.stringify(this.pc.localDescription));
      res(out);
    }catch(e){ rej(e); }
  }); }
  setRemote(answerB64){ return new Promise(async (res,rej)=>{
    try{
      const ans = JSON.parse(atob(answerB64));
      await this.pc.setRemoteDescription(ans);
      res();
    }catch(e){ rej(e); }
  }); }
  _waitForIceComplete(timeout=3000){ return new Promise((res)=>{
    const check = ()=>{
      if(this.pc.iceGatheringState==='complete') return res();
      setTimeout(()=>{ if(this.pc.iceGatheringState==='complete') res(); else res(); }, timeout);
    };
    check();
  }); }
  send(obj){ try{ if(this.dc && this.dc.readyState==='open') this.dc.send(JSON.stringify(obj)); }catch(e){console.warn('send fail',e);} }
}

// --- Extra helpers: export/import signaling file & lobby chat support ---
// Export current box content to file
function downloadTextFile(filename, text){
  const blob = new Blob([text], {type:'text/plain'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
  URL.revokeObjectURL(a.href);
}
// expose utility globally for multiplayer page
window._p2putils = { downloadTextFile };
